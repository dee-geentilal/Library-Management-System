<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>ERROR!</title><"Styles.css"/>
        <link href="https://fonts.googleapis.com/css?family=Pacifico" rel="stylesheet">
    </head>
    <body>
        <h1>OOPS...Something went wrong!</h1>
        <h2>Please try again :)</h2>
        <a href="Login.php">
            <button>Login</button>
        </a>
    </body>
</html>
