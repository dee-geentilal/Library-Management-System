<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Book Results</title>
        <link rel="stylesheet" href="Styles.css"/>
        <link href="https://fonts.googleapis.com/css?family=Pacifico" rel="stylesheet">
    </head>
    <body>
        
        <h3>Results:</h3>
        <h3>Availability:</h3>
        
        <a href="StaffPage.php">
            <button>Search again</button>
        </a>
        <br/>
        <a href="Logout.php">
            <button>Logout</button>
        </a>
    </body>
</html>
