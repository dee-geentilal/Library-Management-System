<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Logout</title>
        <link rel="stylesheet" href="Styles.css"/>
        <link href="https://fonts.googleapis.com/css?family=Pacifico" rel="stylesheet">
    </head>
    <body>
        <h2>You have successfully logged out.</h2>
        <h3>See you soon!</h3>
        <a href="Login.php">
            <button>Login</button>
        </a>
    </body>
</html>
